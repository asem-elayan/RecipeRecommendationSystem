import json
import urllib.error
import urllib.request

from yummly_scraper import settings
from yummly_scraper.utils import format_url, merge_dicts


# TODO: get all the ingredients and their categories (in a dict)


class ScrapingException(Exception):
	pass


def get_request(url, retries=0):
	if retries >= settings.MAX_RETRIES:
		raise Exception(f'TimedOut {retries} times')
	req = urllib.request.Request(url)
	req.add_header('Content-Type', 'application/json')
	req.add_header('user-agent', 'Mozilla/5.0')

	response = None
	try:
		response = urllib.request.urlopen(req, timeout=10000)
	except urllib.error.HTTPError as e:
		if e.code == 403:
			raise
		elif e.code == 408:
			print(f'Timed out for {url}, retrying')
			return get_request(url, retries + 1)
	if not response:
		raise Exception(f'Failed to open {url}')
	if response.code == 403:
		raise ScrapingException(f'Forbidden on {url}')
	elif response.code == 408:
		return get_request(url, retries + 1)
	elif response.code != 200:
		raise Exception(f'Failed to open url {url}')
	data = response.read()
	if data is None or len(data) == 0:
		raise Exception(f'Empty response from {url}')
	feed = json.loads(data)['feed']
	if len(feed) == 0:
		print('\t\tFeed is empty, retrying')
		return get_request(url, retries + 1)
	return feed


def parse_ingredients(ingredient_lines):
	res = []
	categories = dict()
	for ingredient_data in ingredient_lines:
		ingredient = dict()
		name = ingredient_data['ingredient']
		category = ingredient_data['category']
		if name is None or category is None:
			continue
		if category not in categories:
			categories[category] = {name.lower()}
		else:
			categories[category].add(name.lower())

		ingredient['name'] = name
		ingredient['category'] = category

		amount = ingredient_data['amount']['metric']
		if amount is not None and amount['unit'] is not None:
			ingredient['unit'] = amount['unit']['abbreviation']
			ingredient['unit_type'] = amount['unit']['kind']
			ingredient['quantity'] = amount['quantity']
		res.append(ingredient)
	return res, categories


def parse_recipe(recipe_data, carb, piquant):  # feed
	categories = dict()

	content = recipe_data['content']
	ingredients, cat = parse_ingredients(content['ingredientLines'])
	categories = merge_dicts(categories, cat)
	desc = ""
	if content['description'] is not None:
		desc = content['description']['text']
	recipe = {
		'name': content['details']['name'],
		'piquant_level': piquant,
		'carb_source': carb,
		'sevings': content['details']['numberOfServings'],
		'reviews_count': content['reviews']['totalReviewCount'],
		'cooking_time': content['details']['totalTimeInSeconds'],
		'rating': content['reviews']['averageRating'],
		'yums': content['yums']['count'],
		'page_url': content['details']['attribution']['url'],
		'image_url': recipe_data['display']['images'],
		'ingredients': ingredients,
		'preparation_steps': content['preparationSteps'],
		'description': desc
	}
	return recipe, categories


def scrap_recipes(protein, carb, piquant):
	try:
		print(f'scraping recipes with {protein} and {carb} and is {piquant}')
		res = []
		ingredients = dict()

		url = format_url(protein, carb, piquant)

		data1 = get_request(url.format(1, 498))  # gets the first 498 recipes
		for recipe_data in data1:
			recipe, cat = parse_recipe(recipe_data, carb, piquant)
			res.append(recipe)
			ingredients = merge_dicts(ingredients, cat)
		print('\tparsed the first 498 recipes')

		# data2 = get_request(url.format(499, 1400))
		# for recipe_data in data2:
		# 	recipe, cat = parse_recipe(recipe_data, carb, piquant)
		# 	res.append(recipe)
		# 	ingredients = merge_dicts(ingredients, cat)
		# print('\tparsed another 1499 recipes')

		for cat in ingredients:
			ingredients[cat] = sorted(list(ingredients[cat]))
		with open(f'data/yummly_{protein}_{carb}_{piquant}.json', 'w') as file:
			file.write(json.dumps({'recipes': res, 'ingredient_categories': ingredients}, indent=4))
	except Exception as e:
		print(f'Failed to scrap {protein}, {carb}, {piquant}. Error: {e}')


if __name__ == '__main__':
	# scrap_recipes("chicken", "potatoes", "mild")
	# scrap_recipes("chicken", "potatoes", "spicy")
	# scrap_recipes("chicken", "rice", "mild")
	# scrap_recipes("chicken", "rice", "spicy")
	# scrap_recipes("chicken", "bread", "mild")
	# scrap_recipes("chicken", "bread", "spicy")
	# scrap_recipes("chicken", "pasta", "mild")
	# scrap_recipes("chicken", "pasta", "spicy")
	# scrap_recipes("beef", "potatoes", "mild")
	# scrap_recipes("beef", "potatoes", "spicy")
	# scrap_recipes("beef", "rice", "mild")
	# scrap_recipes("beef", "rice", "spicy")
	# scrap_recipes("beef", "bread", "mild")
	# scrap_recipes("beef", "bread", "spicy")
	# scrap_recipes("beef", "pasta", "mild")
	# scrap_recipes("beef", "pasta", "spicy")
	# scrap_recipes("pork", "potatoes", "mild")
	# scrap_recipes("pork", "potatoes", "spicy")
	# scrap_recipes("pork", "rice", "mild")
	scrap_recipes("pork", "rice", "spicy")
	# scrap_recipes("pork", "bread", "mild")
	# scrap_recipes("pork", "bread", "spicy")
	# scrap_recipes("pork", "pasta", "mild")
	# scrap_recipes("pork", "pasta", "spicy")
	# for protein in ['beef', 'pork', 'chicken']:
	# 	for carb in ['bread', 'pasta', 'rice', 'potatoes']:
	# 		for piquant in ['mild', 'spicy']:
	# 			scrap_recipes(protein, carb, piquant)
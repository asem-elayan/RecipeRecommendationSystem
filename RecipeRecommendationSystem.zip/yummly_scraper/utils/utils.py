import requests

from yummly_scraper import settings


def get_recipes_count(url):
	"""
	Gets the total recipes count for the current filter url for yummly.com api

	set maxResults to 0 to minimize data transfer (not necessary)

	"""
	r = requests.get(url)
	if r.status_code != 200:  # OK
		return 0
	data = r.json()
	return data['totalMatchCount'] if 'totalMatchCount' in data.keys() else 0


def format_url(protein, carb, piquant_level):
	url = settings.API_URL
	url += settings.API_FILTER_PROTEINS.format(protein, *settings.PROTEINS_FILTERS[protein])
	url += settings.API_FILTER_CARBS.format(carb, *settings.CARBS_FILTERS[carb])
	url += settings.API_FILTER_PIQUANT.format(*settings.PIQUANT_FILTERS[piquant_level])

	return url


def merge_dicts(dict1, dict2):
	res = dict()
	res.update(dict1)
	for key in dict2:
		if key not in res:
			res[key] = dict2[key]
		else:
			res[key] = res[key].union(dict2[key])
	return res

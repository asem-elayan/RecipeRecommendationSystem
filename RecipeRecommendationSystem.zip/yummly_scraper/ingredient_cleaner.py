import json
import re

import nltk
from nltk.tokenize import word_tokenize


def clean_pepper(word, category):
	if 'pepper' not in word and 'jala' not in word and 'chili' not in word and 'chill' not in word:
		return word

	if category == 'Baking & Cooking':
		if 'cayenn' in word:
			return 'cayenne'
		if 'black' in word or 'white' in word:
			return 'black pepper'
		return 'chili powder'
	elif category == 'Produce':
		if 'bell' in word or 'sweet' in word or word == 'pepper' or word == 'peppers':
			return 'sweet pepper'
		else:
			return 'hot pepper'
	elif category == 'Condiments':
		if 'peppercorn' in word:
			return 'black pepper'
		elif 'pepper sauc' in word or 'pepper paste':
			return 'hot sauce'
		elif 'pepper' in word:
			return 'hot pepper'
	return word


def reduce_categories(name, category):
	if category == 'Alcohol':
		return 'alcohol'
	elif category == 'Seafood' and 'anchov' not in name:
		return 'seafood'
	elif category == 'Coffee & Tea':
		return 'coffee-tea'
	elif category == 'Frozen Desserts':
		return 'frozen desserts'
	else:
		return name


def remove_categories(category):
	to_remove = [
		'Meat',
		'Bakery',
		'Floral',
		'Packaged Meals & Side Dishes',
		'Soy Products',
		'Pharmacy & First-Aid',
		'Other',
		'null'
	]
	return category in to_remove


def clean_tokens(word, category):  # FIXME plz think of a better name

	tokens = {
		'garlic': 'garlic powder' if category == 'Baking & Cooking' else 'garlic',
		'onion': 'onion powder' if category == 'Baking & Cooking' else 'onion',
		'shallot': 'shallot',
		'salt': 'salt',
		'stock': 'stock',
		'broth': 'stock',
		'gravy': 'stock',
		'bouillon': 'stock',
		'soup': 'stock',
		'cheese': 'cheese',
		'mozzarella': 'cheese',
		'cheddar': 'cheese',
		'ricotta': 'cheese',
		'milk': 'milk',
		'heavy cream': 'heavy cream',
		'whipping cream': 'heavy cream',
		'sour cream': 'sour cream',

		'parme': 'cheese',
		'mushroom': 'mushroom',
		'shiitake': 'mushroom',
		'cabbage': 'cabbage',
		'lettuce': 'lettuce',
		'tomato': 'tomato',
		'marinara': 'tomato',
		'vinegar': 'vinegar',
		'bean': 'beans',
		'soy': 'soy',
		'egg': 'eggs',
		'crumb': 'crumbs',
		'apple': 'apple',
		'basil': 'basil',
		'anchov': 'anchovy',
		'syrup': 'syrup',
		'oat': 'oats',
		'waffl': 'waffle',
		'cereal': 'cereal',
		'molass': 'syrup',
		'guacamole': 'avocado',
		'avocado': 'avocado',
		'hot sauce': 'hot sauce',
		'tabasco': 'hot sauce',
		'mayo': 'mayonnaise',
		'mustard': 'mustard',
		'pickle': 'pickles',
		'jam': 'jam',
		'dressing': 'dressing',
		'worchestire': 'worchestire sauce',
		'worcestershire': 'worchestire sauce',
		'sour sauce': 'sweet and sour sauce',
		'margarin': 'margarin',

		'radish': 'horse radish' if category == 'Condiments' else word,
		'relish': 'relish',
		'olive': 'olives',
		'teriyaki': 'teriyaki',
		'barbeque': 'bbq',
		'bbq': 'bbq',
		'yogurt': 'yogurt',
		'peppercorn': 'black pepper',
		'curry': 'curry',
		r'corn\s?flakes?': 'cereal',
		'hash': '',
		'corn': 'corns',
		'vegetable': 'vegetables',
		r'cole\s?slaw': 'cole slaw',
		'ranch': 'ranch',
		'hummus': 'hummus',
		'garbanzo': 'hummus',
		r'chick\s?pea': 'hummus',
		'pineappl': 'pineapple',
		'brocc': 'broccoli',
		'cauli': 'cauliflower',
		'rice': '',
		'potato': '',
	}
	for token in tokens:
		r = re.compile(token)
		if r.search(word) is not None:
			return tokens[token]
	return word


def clean_redundant(name: str, category):
	redundant = [
		'ground',
		'fresh',
		'crushed',
		'powder',
		'granulated',
		'hungarian',
		'dried',
		'leaves',
		'extra',
		'virgin',
		'roasted',
		'pure',
		'extra virgin',
		'flakes',
		'seeds',
		'fine',
		'neutral',
		'smoked',
		'kosher',
		'cracked',
		'dehydrated',
		'red',
		'hot',
		'dry',
		'dark',
		'brown',
		'crushed',
		'Diamond',
		'Crystal',
		'light',
		'brown',
		'sorghum',
		'white',
		'coarse',
		'toasted',
		'blanched',
		'threads',
		'freshly',
		'all purpose',
		'warm',
		'hot',
		'filtered',
		'juice',
		'orange',
		'sprouts',
		'head',
		'minced',
		'hearts',
		'roma',
		'chopped',
		'spring',
		'wedge',
		'small',
		'sweet',
		'green',
		'floret',
		'baby',
		'baking',
		'medium',
		'leaves',
		'leaf',
		'garnish',
		'chips',

		'slices',
		'whole',
		'ripe',

	]
	for word in redundant:
		if word in name:
			name.replace(word, '')
	return name


def clean_dairy(name, category):
	if category != 'Dairy':
		return name

	if 'jack' in name:
		return 'cheese'

	if 'butter' in name:
		if 'milk' in name:
			return 'buttermilk'
		elif 'cup' in name:
			return 'buttercup'
		elif 'apple' in name:
			return 'apple butter'
		elif 'peanut' in name or 'almond' in name or 'cashew' in name:
			return 'nut butter'
		else:
			return 'butter'

	if 'milk' in name:
		if 'coconut' in name:
			return 'coconut milk'
		elif 'nut' in name or 'cashew' in name or 'almond' in name:
			return 'nut milk'
	return name


def clean_nuts(name, category):
	if category == 'Dairy':
		return name
	if 'coconut' in name:
		return 'coconut'
	elif 'cashew' in name or 'pecan' in name or 'pistachio' in name or 'almond' in name or 'nut' in name:
		return 'nut'
	else:
		return name


def clean_starches(name, category):
	if 'starch' in name:
		return 'starch'
	return name


def clean_oils(name, category):  # after dairy, before tokens
	if 'spary' in name and 'olive' not in name:
		return 'cooking oil'
	elif 'oil' in name:
		if 'olive' in name:
			return 'olive oil'
		elif 'canola' in name or 'sesame' in name or 'cooking' in name:
			return 'cooking oil'
	return name


def clean_nlp(word: str, category):
	word = word.replace('-', ' ')
	tokens = word_tokenize(word)
	pos = nltk.pos_tag(tokens)
	verb_pos = ['VB', 'VBD', 'VBG', 'VBN', 'VBD', 'VBZ']
	# noun_pos = ['NN', 'NNS', 'NNP', 'NNPS', 'JJ']
	cleaned_pos = filter(lambda x: x[1] not in verb_pos, pos)
	cleaned_word = map(lambda x: x[0], cleaned_pos)

	return ' '.join(cleaned_word)


if __name__ == '__main__':
	with open('../all_ingredients.json') as file:
		data = json.loads(file.read())

	filters = [
		clean_pepper,
		clean_starches,
		clean_dairy,
		clean_oils,
		reduce_categories,
		clean_tokens,
		clean_nuts,
		clean_redundant,
		clean_nlp,
	]

	res = dict()
	for cat in data:
		if remove_categories(cat):
			continue
		print(f'\rCleaning category: {cat}', end='', flush=True)
		cat_res = set()
		for i in data[cat]:
			for filt in filters:
				cleaned_i = filt(i, cat)
				if i != cleaned_i:
					i = cleaned_i
					break
			cat_res.add(i)
		res[cat] = list(cat_res)

	with open('../cleaned_tst.json', 'w') as file:
		file.write(json.dumps(res, indent=4))
		pass
